<?php

class AppModel extends Database{
        
	public function app_install($devIceNumber){
		try{
	$sqlQ=$this->_connection->query("Mysql query here ");     
 	 
		  } catch (PDOException $e) { parent::close();
		  die( "Connection failed: " . $e->getMessage());
	        }
        }
 
}
?>
