<?php
error_reporting(0);
// Constant Define stArt    (Krisihan Thakur -> date-06/FEB/2017)
define('__ROOT__', dirname(__FILE__));
define('___ROOT___', dirname(dirname(__FILE__)));
require(__ROOT__.'/config/database.php');
require(__ROOT__.'/model/appModel.php');

?>
